/* Configuration file for template_server.c and template_client.c */

#ifndef INCL_TEMPLATE_CONFIG
#define INCL_TEMPLATE_CONFIG  1

#define PACKET_SIZE  (2 * 1024)


#endif /* INCL_TEMPLATE_CONFIG */
